package com.niit.shoppingbackend;

import org.springframework.context.annotation.AnnotationConfigApplicationContext;

import com.niit.shoppingbackendDAO.LoginDAO;
import com.niit.shoppingbackendmodel.Login;

public class LoginTest {

	public static void main(String[] args) {
		AnnotationConfigApplicationContext context = new AnnotationConfigApplicationContext();
		context.scan("com.niit");
		context.refresh();
		LoginDAO loginDAO = (LoginDAO) context.getBean("loginDAO");
		Login login = (Login) context.getBean("login");
		
	
		
		loginDAO.save(login);
		loginDAO.Update(login);
		

		/*if (loginDAO.get("sdfsf") == null) {
			System.out.println("Login does not exist");
		} else {
			System.out.println("Login exist.....the details are..");
			System.out.println();
		}*/



	}

}
