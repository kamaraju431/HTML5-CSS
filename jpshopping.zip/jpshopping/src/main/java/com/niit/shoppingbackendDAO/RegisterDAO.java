package com.niit.shoppingbackendDAO;

import java.util.List;

import com.niit.shoppingbackendmodel.Login;
import com.niit.shoppingbackendmodel.Register;

public interface RegisterDAO {
	public List<Register> list();
	public Login get(int id);
	public void saveOrUpdate(Register register);
	public void delete(int id);
}
