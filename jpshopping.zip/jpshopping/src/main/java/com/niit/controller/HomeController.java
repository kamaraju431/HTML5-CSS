package com.niit.controller;

import java.io.BufferedInputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.OutputStream;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import javax.validation.Valid;

import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.ui.ModelMap;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.servlet.ModelAndView;

import com.google.gson.Gson;
import com.niit.shoppingbackendDAO.LoginDAO;
import com.niit.shoppingbackendDAO.ProductDAO;
import com.niit.shoppingbackendDAO.RegisterDAO;
import com.niit.shoppingbackendmodel.Login;
import com.niit.shoppingbackendmodel.Product;
import com.niit.shoppingbackendmodel.Register;

@Controller

public class HomeController {
	@Autowired
	private ProductDAO pd;
	@Autowired
	private RegisterDAO us;
	@Autowired
	private LoginDAO lu;

	SessionFactory sessionFactory;

	@RequestMapping("/")
	public ModelAndView display() {
		ModelAndView m1 = new ModelAndView("index");
		return m1;
	}

	@RequestMapping("/Login")
	public ModelAndView display1() {
		ModelAndView m1 = new ModelAndView("Login");
		return m1;
	}

	@RequestMapping("/about")
	public ModelAndView display6() {
		ModelAndView m1 = new ModelAndView("about");
		return m1;
	}

	@RequestMapping("/contactus")
	public ModelAndView display7() {
		ModelAndView m1 = new ModelAndView("contactus");
		return m1;
	}

	@RequestMapping("/register")
	public ModelAndView display2() {
		ModelAndView m3 = new ModelAndView("register");
		return m3;
	}

	@RequestMapping("/addproduct")
	public ModelAndView display4() {
		ModelAndView m4 = new ModelAndView("addproduct");
		return m4;
	}

	@RequestMapping("/index2")
	public ModelAndView display6(HttpServletRequest request) {
		String str = request.getParameter("email");
		ModelAndView m1 = new ModelAndView("index2");
		return m1;
	}

	@ModelAttribute("Product")
	public Product createProduct() {
		return new Product();
	}

	@RequestMapping("/storeproduct")
	public String addmobile(HttpServletRequest request, @Valid @ModelAttribute("Product") Product product,
			BindingResult result) {
		System.out.println("hello niit...........................");
		System.out.println(product.getId());
		System.out.println(product.getName());
		System.out.println(product.getDescription());
		System.out.println(product.getPrice());
		System.out.println(product.getImg());
		if (result.hasErrors()) {
			return "addproduct";
		}
		System.out.println(product);
		String filename = product.getImg().getOriginalFilename();
		// product.getImg().getOriginalFilename();
		System.out.println("KAMA RAJU..........." + filename);
		product.setImage(filename);

		try {
			byte[] bytes = new byte[product.getImg().getInputStream().available()];
			System.out.println("one");
			product.getImg().getInputStream().read(bytes);
			System.out.println("two");
			BufferedInputStream buffer = new BufferedInputStream(product.getImg().getInputStream());
			System.out.println("three");
			MultipartFile file = product.getImg();
			String path = request.getServletContext().getRealPath("/") + "resources/images";

			File rootPath = new File(path);

			if (!rootPath.exists())
				rootPath.mkdirs();

			File store = new File(rootPath.getAbsolutePath() + "/" + filename);

			System.out.println("Image path :" + path);

			OutputStream os = new FileOutputStream(store);

			os.write(bytes);
		} catch (Exception e) {
			System.out.println(e.getMessage());
		}
		pd.saveOrUpdate(product);

		return "display";
	}

	@RequestMapping("hai")
	public String display3() {
		return "index";
	}

	@ModelAttribute("Register")
	public Register createUser() {
		return new Register();
	}

	@RequestMapping(value = "storeUser", method = RequestMethod.POST)
	public String addUser(@Valid @ModelAttribute("Register") Register registeruser,
			 BindingResult result, Model model) {
		System.out.println(registeruser.getUsername());
		System.out.println(registeruser.getAddress());
		System.out.println(registeruser.getPassword());
		System.out.println(registeruser.getConfirmpassword());
		System.out.println(registeruser.getId());
		System.out.println(registeruser.getEmail());
		System.out.println(registeruser.getMobilenumber());

		if (result.hasErrors()) {
			System.out.println("hi");

			return "register";
		}
		Login loginuser=new Login();
		System.out.println("hello storeUser");
		System.out.println(registeruser.getUsername() + "hello @@@@@@");
		us.saveOrUpdate(registeruser);
		loginuser.setId(registeruser.getId());
		loginuser.setUsername(registeruser.getUsername());
		loginuser.setPassword(registeruser.getPassword());
		loginuser.setStatus(registeruser.getStatus());
		lu.save(loginuser);
		return "register";
	}

	@RequestMapping("/display")
	public ModelAndView retriveRecords() {
		ModelAndView m1 = new ModelAndView("display");
		return m1;
	}

	@RequestMapping(value = "/list", method = RequestMethod.GET, produces = "application/json")
	public @ResponseBody String showList() {
		List list = pd.list();
		Gson x = new Gson();
		String json = x.toJson(list);
		return json;
	}

	@RequestMapping(value = "viewproduct", method = RequestMethod.GET)
	public ModelAndView viewproduct(@RequestParam int id, @ModelAttribute Product products) {
		System.out.println(id);
		System.out.println(products.getId());
		Product product = pd.get(id);
		return new ModelAndView("viewproduct", "product", product);
		// return new ModelAndView("viewproduct");
	}

	@RequestMapping("/delete")
	public ModelAndView deleteChair(@RequestParam int id) {
		System.out.println("hello welcome to niit");
		pd.delete(id);
		ModelAndView model = new ModelAndView("display");
		return model;
	}

	@RequestMapping(value = "editproduct", method = RequestMethod.GET)
	public ModelAndView updateProduct(@RequestParam int id) {
		Product p1 = pd.get(id);
		return new ModelAndView("editproduct", "product", p1);
	}

	@RequestMapping("editproduct")
	public ModelAndView display9() {
		ModelAndView m9 = new ModelAndView("editproduct");
		return m9;
	}

	@RequestMapping(value = "/fail2login", method = RequestMethod.GET)
	public ModelAndView loginerror(ModelMap model) {
		System.out.println("hello yogi...........................................");

		return new ModelAndView("Login", "error", true);
	}

	@RequestMapping(value = "/welcome", method = RequestMethod.GET)
	public ModelAndView checkUserOne(HttpServletRequest request, HttpServletResponse response, HttpSession session)
			throws Exception {
		System.out.println("hi");
		if (request.isUserInRole("ROLE_ADMIN")) {
			Authentication auth = SecurityContextHolder.getContext().getAuthentication();
			String str = auth.getName(); // get logged in username
			session = request.getSession(true);
			session.setAttribute("loggedInUser", str);

			// session.invalidate();
			ModelAndView m1 = new ModelAndView("Admin");
			return m1;
		} else {
			Authentication auth = SecurityContextHolder.getContext().getAuthentication();
			String str = auth.getName(); // get logged in username
			session = request.getSession(true);
			session.setAttribute("loggedInUser", str);
			ModelAndView m2 = new ModelAndView("index2");
			return m2;
		}

	}

	
	@RequestMapping("/displayuser")
	public ModelAndView retriveRecordsuser() {
		ModelAndView m1 = new ModelAndView("displayuser");
		return m1;
	}

	@RequestMapping("/edituser")
	public String edituser() {
		return "edituser";
	}

		@RequestMapping(value = "/list1", method = RequestMethod.GET, produces = "application/json")
	public @ResponseBody String showList2() {
		List<Login> list = lu.list();
		Gson u = new Gson();
		String json = u.toJson(list);
		return json;
	}

	@RequestMapping(value = "edituser", method = RequestMethod.GET)
	public ModelAndView edituser(@RequestParam int id, @ModelAttribute("Login") Login login) {
		System.out.println("hello kamu............");
		Login u1 = lu.get(id);
		System.out.println("hai.............");

		return new ModelAndView("edituser", "login", u1);
	}
	@ModelAttribute("Login")
	public Login newlogin(){
		return new Login();
	}
	@RequestMapping(value = "/updateuser", method = RequestMethod.POST)
	public ModelAndView updateuser(HttpServletRequest request, @Valid @ModelAttribute("Login") Login login) {
		lu.Update(login);
		return new ModelAndView("displayuser");
	}

	@RequestMapping("/deleteuser")
	public ModelAndView deleteuser(@RequestParam int id) {
		System.out.println("hello");
		lu.delete(id);
		us.delete(id);
		ModelAndView model2 = new ModelAndView("displayuser");
		return model2;
	}
	
	
	
	
	@RequestMapping("logoutsuccess")
	public ModelAndView logoutpage(){
		ModelAndView mv9 = new ModelAndView("logoutsuccess");
		return mv9;
	}

	@RequestMapping(value = "/Logout", method = RequestMethod.GET)
	public void logout(HttpServletRequest request, HttpServletResponse response, HttpSession session)
			throws ServletException, IOException {
		HttpSession newsession = request.getSession(false);
		if (newsession != null) 
	    {
	         newsession.invalidate();

	    }
		response.sendRedirect("j_spring_security_logout");	
		
	}


	
	
	
	 @RequestMapping(value="viewcart",method=RequestMethod.GET)
		public ModelAndView vc(@RequestParam int id, @ModelAttribute Product product)
		{  
	    	Product pro1=pd.get(id);
	    	return new ModelAndView("viewcart","product",pro1); 
		}	 


}


	
	 


