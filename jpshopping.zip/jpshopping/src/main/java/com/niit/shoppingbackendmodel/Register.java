package com.niit.shoppingbackendmodel;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;

@Entity
@Table(name="register")
public class Register {
	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	@Column(name="id")
	private int id;
	
	@NotNull
	@Size(min=2,max=30,message="Name Must be more than 2 letters")
	@Column(name="username")
	
	private String username;

	

	 @NotNull
	 @Size(min=2,max=30)
	 @Column(name="password")
     private String password;
	 
	 @NotNull
	 @Size(min=2,max=30)
	 @Column(name="confirmpassword")
     private String confirmpassword; 
	 
	 @NotNull
		@Size(min=2,max=30,message="Mobile number Must be 10 numbers")
		@Column(name="mobilenumber")
		
		private String mobilenumber;
	 
	 @NotNull
		@Size(min=2,max=30,message="Email Must be @ ")
		@Column(name="Email")
		
		private String Email;
	 
	 @NotNull
		@Size(min=2,max=30,message="address Must and should")
		@Column(name="address")
		
		private String address;
	 @NotNull
		@Column(name="status")
			private boolean status=true;
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getUsername() {
		return username;
	}
	public void setUsername(String username) {
		this.username = username;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	public String getConfirmpassword() {
		return confirmpassword;
	}
	public void setConfirmpassword(String confirmpassword) {
		this.confirmpassword = confirmpassword;
	}
	public String getMobilenumber() {
		return mobilenumber;
	}
	public void setMobilenumber(String mobilenumber) {
		this.mobilenumber = mobilenumber;
	}
	public String getEmail() {
		return Email;
	}
	public void setEmail(String email) {
		Email = email;
	}
	public String getAddress() {
		return address;
	}
	public void setAddress(String address) {
		this.address = address;
	}
	public boolean getStatus() {
		return status;
	}
	public void setStatus(boolean status) {
		this.status = status;
	}

	 	
	 
	}
